import PicGoCore from 'picgo'
export default PicGoCore
