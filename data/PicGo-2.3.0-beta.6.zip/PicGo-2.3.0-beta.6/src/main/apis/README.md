# apis folder

## core

The lowest level APIs that are not dependent on each other. The upper APIs depend on them.

## app

Provide key API interfaces for PicGo application, including uploader, window management, shortcut key system, etc

## gui

GuiApi for PicGo plugins.
