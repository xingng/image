import picgo from '.'

const logger = picgo.log

export default logger
